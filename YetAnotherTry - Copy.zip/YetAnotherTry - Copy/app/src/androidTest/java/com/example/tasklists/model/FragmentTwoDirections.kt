package com.example.tasklists.model

class FragmentTwoDirections {

}
