package com.example.tasklists.model

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.FloatProperty
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.NavArgsLazy
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.hrsalterego.yetanothertry.R
import kotlin.reflect.KProperty
import com.example.tasklists.model.FragmentTwo.FragmentTwoArgs as FragmentTwoArgs1

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class FragmentTwo() : Fragment() {
    val args: FragmentTwoArgs1 by FragmentTwoArgs()

    class FragmentTwoArgs {
        operator fun getValue(fragmentTwo: FragmentTwo, property: KProperty<*>): Unit =
            Unit

        val editData: Any
            get() {
                TODO()
            }
    }

    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(
            R.layout.fragment_two,
            container,
            false
        )
        //inflate FragmentTwo class
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.i("app", "get data back")
        val getData: EditText =
            view.findViewById(R.id.saver_task) //Created a var to stand for data entered into the EditText box.
        val task = args.editData

        val newlyWrittenData = view.findViewById<EditText>(R.id.saver_task).text.toString()
        val backToOne = FragmentTwoArgs
        findNavController().navigate(backToOne)
    }
}











