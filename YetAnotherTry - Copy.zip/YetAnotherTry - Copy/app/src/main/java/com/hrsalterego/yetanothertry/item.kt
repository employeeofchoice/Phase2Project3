package com.hrsalterego.yetanothertry

data class Item (val myString: String, val shouldDisplayStar: Boolean)